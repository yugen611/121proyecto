package prototipofinal;

public class Sala {
	private int idSala;
	private String tipo;
	private int capacidad;
	private double precioBase;
	
	public Sala(int idSala, String tipo, int capacidad, double precioBase) {
		this.idSala = idSala;
		this.tipo = tipo;
		this.capacidad = capacidad;
		this.precioBase = precioBase;
	}

	public int getIdSala() {
		return idSala;
	}

	public void setIdSala(int idSala) {
		this.idSala = idSala;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}

	public double getPrecioBase() {
		return precioBase;
	}

	public void setPrecioBase(double precioBase) {
		this.precioBase = precioBase;
	}

	@Override
	public String toString() {
		return "Sala [idSala=" + idSala + ", tipo=" + tipo + ", capacidad=" + capacidad + ", precioBase=" + precioBase
				+ "]";
	}
	
	public void mostarInfo()
	{
		System.out.println(toString());
	}
	
	public double calcularPrecioBase() {
	        return precioBase;
	}
	
	
	

}
