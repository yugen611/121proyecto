package prototipofinal;

import java.util.ArrayList;
import java.util.List;

public class Cine {
	private String nombre;
	private String direccion;
	private List<Funcion> funciones;
	public Cine(String nombre, String direccion) {

		this.nombre = nombre;
		this.direccion = direccion;
		this.funciones = new ArrayList<>();
	}
	
	public void agregarFuncion(Funcion f)
	{
		this.funciones.add(f);
		
	}
	public void buscarFunciones(String funcionx)
	{
		boolean sw=true;
		for(Funcion fun: funciones)
		{
			String s=fun.getPelicula().getTitulo().toLowerCase();
			String n= funcionx.toLowerCase();
			
			if (s.contains(n)) {
				System.out.println("funcion: "+fun.getPelicula().getTitulo()+" "+fun.getHorario());
				sw=false;
				
			} 
		}
		if(!sw)
			System.out.println("no se encontro esa "+funcionx);
	}
	
	public void generarReporte()
	{
		System.out.println("Reporte del cine: " + nombre);
		
		for (Funcion funcion : funciones) {
			System.out.println(funcion.getPelicula().getTitulo()+" - "+funcion.getHorario()+" /Ocupacion: "+ funcion.calcularOcupacion()+"%");
			
		}
	}
	
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public List<Funcion> getFunciones() {
		return funciones;
	}
	public void setFunciones(List<Funcion> funciones) {
		this.funciones = funciones;
	}


	
	
	
	
	

}
