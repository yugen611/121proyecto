package prototipofinal;

public class Boleto {
	private int idBoleto;
	private String asiento;
	private double precioFinal;
	private String fechaCompra;
	private Promocion promocion;
	
	public Boleto(int idBoleto, String asiento, double precioFinal, String fechaCompra) {
		
		this.idBoleto = idBoleto;
		this.asiento = asiento;
		this.precioFinal = precioFinal;
		this.fechaCompra = fechaCompra;
	}
	
	

	@Override
	public String toString() {
		return "Boleto [idBoleto=" + idBoleto + ", asiento=" + asiento + ", precio=" + precioFinal
				+ ", fechaCompra=" + fechaCompra  + "]";
	}
	public void imprimir()
	{
		System.out.println(toString());
	}
	public void aplicarDescuento(Promocion p)
	
	{
		this.promocion=p;
		if(promocion !=null)
		{
			double promo= p.aplicar(this);
			double pr=this.precioFinal;
			this.precioFinal=promo;
			System.out.println("Se aplico el descuento de "+pr+" a "+this.precioFinal);
		}
	}



	public int getIdBoleto() {
		return idBoleto;
	}

	public void setIdBoleto(int idBoleto) {
		this.idBoleto = idBoleto;
	}

	public String getAsiento() {
		return asiento;
	}

	public void setAsiento(String asiento) {
		this.asiento = asiento;
	}

	public double getPrecioFinal() {
		return precioFinal;
	}

	public void setPrecioFinal(double precioFinal) {
		this.precioFinal = precioFinal;
	}

	public String getFechaCompra() {
		return fechaCompra;
	}

	public void setFechaCompra(String fechaCompra) {
		this.fechaCompra = fechaCompra;
	}

	public Promocion getPromocion() {
		return promocion;
	}

	public void setPromocion(Promocion promocion) {
		this.promocion = promocion;
	}
	
	
	

}
