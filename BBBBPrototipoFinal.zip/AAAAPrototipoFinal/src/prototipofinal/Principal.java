package prototipofinal;

public class Principal {

	public static void main(String[] args) {
		
		    Sala sala2D = new Sala(1, "2D", 50, 15.0);
	        SalaPremium salaPremium = new SalaPremium(2, 30, 25.0, true, 10.0); // Polimorfismo

	        System.out.println("Precio sala 2D: " + sala2D.calcularPrecioBase());
	        System.out.println("Precio sala Premium: " + salaPremium.calcularPrecioBase());

	        // ===== 2️⃣ Crear películas =====
	        Pelicula pelicula1 = new Pelicula(1, "Spider-Man", "Acción", 130, "PG-13");
	        Pelicula pelicula2 = new Pelicula(2, "Encanto", "Animación", 95, "G");

	        // ===== 3️⃣ Crear funciones =====
	        Funcion funcion1 = new Funcion(1, "14:00", pelicula1, sala2D);
	        Funcion funcion2 = new Funcion(2, "18:00", pelicula2, salaPremium);
	        Funcion funcion3 = new Funcion(3, "21:00", pelicula1, salaPremium);

	        // ===== 4️⃣ Crear cine =====
	        Cine cine = new Cine("Cine Plaza", "Av. Siempre Viva 123");
	        cine.agregarFuncion(funcion1);
	        cine.agregarFuncion(funcion2);
	        cine.agregarFuncion(funcion3);

	        // ===== 5️⃣ Crear promociones =====
	        Promocion promo10 = new Promocion("Descuento 10%", 10.0);
	        Promocion promo20 = new Promocion("Descuento 20%", 20.0);

	        // ===== 6️⃣ Crear clientes =====
	        Cliente cliente1 = new Cliente(1, "Kevin", "kevin@mail.com", "77777777");
	        Cliente cliente2 = new Cliente(2, "Maria", "maria@mail.com", "88888888");

	        // ===== 7️⃣ Comprar boletos (control de cupos + promociones) =====
	        Boleto boleto1 = new Boleto(1, "A1", sala2D.calcularPrecioBase(), "12/11/2025");
	        Boleto boleto2 = new Boleto(2, "A2", salaPremium.calcularPrecioBase(), "12/11/2025");
	        Boleto boleto3 = new Boleto(3, "B1", salaPremium.calcularPrecioBase(), "12/11/2025");

	        // Aplicar promociones
	        boleto1.aplicarDescuento(promo10); // Spider-Man 2D con 10%
	        boleto2.aplicarDescuento(promo20); // Encanto Premium con 20%
	        // boleto3 sin promoción

	        // Registrar venta en funciones (control de cupos)
	        cliente1.comprarBoleto(funcion1, boleto1);
	        cliente1.comprarBoleto(funcion2, boleto2);
	        cliente2.comprarBoleto(funcion3, boleto3);

	        // =====  Mostrar boletos comprados =====
	        System.out.println("\n=== Boletos Comprados ===");
	        for (Boleto b : cliente1.getBoletos()) {
	            b.imprimir();
	        }
	        for (Boleto b : cliente2.getBoletos()) {
	            b.imprimir();
	        }

	        // =====  Filtrar funciones disponibles por película =====
	        System.out.println("\n=== Funciones de 'Spider-Man' ===");
	        cine.buscarFunciones("Spider-Man");

	        // ===== Generar reporte final del cine =====
	        System.out.println("\n=== Reporte de ventas y ocupación ===");
	        cine.generarReporte();

	        // ===== 1 Verificar control de cupos =====
	        System.out.println("\n=== Verificando control de cupos ===");
	        // Intentar llenar la sala 2D
	        for (int i = 0; i < 60; i++) { // Capacidad 50
	            Boleto b = new Boleto(100 + i, "Fila " + (i / 10 + 1) + " Asiento " + (i % 10 + 1),
	            sala2D.calcularPrecioBase(), "12/11/2025");
	            cliente2.comprarBoleto(funcion1, b);
	        }
	        System.out.println("Ocupación función 14:00: " + funcion1.calcularOcupacion() + "%");
	    }

	

}
