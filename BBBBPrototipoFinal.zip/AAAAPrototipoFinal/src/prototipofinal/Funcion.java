package prototipofinal;

import java.util.ArrayList;
import java.util.List;

public class Funcion {
	private int idFuncion;
	private String horario;
	private int boletosVendidos;
	
	private Pelicula pelicula;
	private Sala sala;
	private List<Boleto> boletos;
	public Funcion(int idFuncion, String horario, Pelicula pelicula, Sala sala) {
		this.idFuncion = idFuncion;
		this.horario = horario;
		this.boletosVendidos = 0;
		this.pelicula = pelicula;
		this.sala = sala;
		this.boletos = new ArrayList<>();
	}
	
	public boolean controlarCupos()
	{
		if (this.boletosVendidos<sala.getCapacidad()) {
			return true;
		}
		else
			return false;
	}
	public void registraVenta(Boleto b)
	
	{

		if(controlarCupos())
		{
			boletos.add(b);
			this.boletosVendidos++;

			
		}

		
	}
	public double calcularOcupacion()
	{
		double x= (double)this.boletosVendidos;
		double porcentaje= (x/sala.getCapacidad())*100;
		return porcentaje;
	}
	

	public int getIdFuncion() {
		return idFuncion;
	}

	public void setIdFuncion(int idFuncion) {
		this.idFuncion = idFuncion;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

	public int getBoletosVendidos() {
		return boletosVendidos;
	}

	public void setBoletosVendidos(int boletosVendidos) {
		this.boletosVendidos = boletosVendidos;
	}

	public Pelicula getPelicula() {
		return pelicula;
	}

	public void setPelicula(Pelicula pelicula) {
		this.pelicula = pelicula;
	}

	public Sala getSala() {
		return sala;
	}

	public void setSala(Sala sala) {
		this.sala = sala;
	}

	public List<Boleto> getBoletos() {
		return boletos;
	}

	public void setBoletos(List<Boleto> boletos) {
		this.boletos = boletos;
	}
	
	
		
		
	
	
	
	
	
	

}
