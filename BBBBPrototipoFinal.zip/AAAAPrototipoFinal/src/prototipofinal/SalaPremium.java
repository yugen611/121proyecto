package prototipofinal;

public class SalaPremium extends Sala{
	private boolean servicioVip;
	private double recargo;
	
	
	public SalaPremium(int idSala, int capacidad, double precioBase,boolean servicio, double recar) {
		super(idSala, "Premium", capacidad, precioBase);
		servicioVip=servicio;
		this.recargo=recar;
	}
	
	public double calcularPrecioBase() {
		return super.calcularPrecioBase()+this.recargo;
		
	}

	@Override
	public String toString() {
		return "SalaPremium [servicioVip=" + servicioVip + ", recargo=" + recargo + "]";
	}
	public void mostarInfo()
	{
		super.mostarInfo();
		System.out.println(toString());
	}

	public boolean isServicioVip() {
		return servicioVip;
	}

	public void setServicioVip(boolean servicioVip) {
		this.servicioVip = servicioVip;
	}

	public double getRecargo() {
		return recargo;
	}

	public void setRecargo(double recargo) {
		this.recargo = recargo;
	}
	
	
	
	

}
