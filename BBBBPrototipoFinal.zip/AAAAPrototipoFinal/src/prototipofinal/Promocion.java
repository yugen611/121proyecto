package prototipofinal;

public class Promocion {
	private String tipo;
	private double procentaje;
	
	public Promocion(String tipo, double procentaje) {
		this.tipo = tipo;
		this.procentaje = procentaje;
	}
	
	public double aplicar(Boleto b ){
		double descuento= b.getPrecioFinal()*(this.procentaje/100);
		double descFinal = b.getPrecioFinal()-descuento;
		return descFinal;
		
		
		
	}

	@Override
	public String toString() {
		return "Promocion [tipo=" + tipo + ", procentaje=" + procentaje + "]";
	}
	
	
	
	

}
